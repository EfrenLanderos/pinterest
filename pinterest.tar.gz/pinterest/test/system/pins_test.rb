require "application_system_test_case"

class PinsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit pins_url
  #
  #   assert_selector "h1", text: "Pin"
  # end
end
